var planeta 
function Button1(){
planeta = document.getElementById("textbox").value;

var distancia
distancia = parseFloat(distancia)

if (planeta=="Marte"){
  alert("Distância até Marte =227.940.000km ")
  distancia=227940000
}
  else if (planeta=="Mercúrio"){
    alert("Distância até Mercúrio = 57.910.000 km")
  }
  else if (planeta=="Vênus"){
    alert("Distância até Vênus = 108.200.000 km")
  }
else if (planeta=="Terra"){
  alert("Distância até a Terra = 149.600.000 km")
}
else if (planeta=="Júpiter"){
   alert("Distância até Júpiter = 778.330.000 km")
}
else if (planeta=="Saturno"){
   alert("Distância até Saturno = 1.429.400.000 km")
}
else if (planeta=="Urano"){
   alert("Distância até Urano = 2.870.990.000 km")
}
else if (planeta=="Netuno"){
   alert("Distância até Netuno = 4.504.300.000 km")
}
else if (planeta=="Plutão"){
   alert("Distância até Plutão = 5.922.000.000 km")
}

}





